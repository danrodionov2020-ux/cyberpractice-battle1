export const LIVE_SUBJECTS = ['Networking & Protocols', 'Cybersecurity', 'CompTIA A+', 'Nightshift Mixed', 'AP Chemistry'] as const;
export type LiveSubject = typeof LIVE_SUBJECTS[number];
export const DEFAULT_SUBJECT: LiveSubject = 'Networking & Protocols';
