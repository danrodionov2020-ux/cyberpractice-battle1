'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { createClient } from '@/lib/supabase/client';
import curriculum from '@/data/learning-paths.json';

type Lesson = { id: string; title: string };
type Course = { id: string; title: string; category: string; level: string; icon: string; description: string; units: { id: string; title: string; lessons: Lesson[] }[] };
const courses = curriculum as Course[];
const icons: Record<string,string> = {shield:'⬡',network:'⌘',terminal:'>_',cpu:'▦',code:'</>',radar:'◉',cloud:'☁',key:'⌑',search:'⌕',target:'◎'};

export default function DashboardPage() {
  const [progress,setProgress] = useState<Record<string,string[]>>({});
  const [name,setName] = useState('Operator');
  const [loading,setLoading] = useState(true);
  useEffect(()=>{
    let alive=true;
    (async()=>{
      const supabase=createClient();
      const {data:{user}}=await supabase.auth.getUser();
      if(!alive)return;
      setName((user?.user_metadata?.display_name as string)||user?.email?.split('@')[0]||'Operator');
      if(user){
        const {data}=await supabase.from('learning_progress').select('course_id,completed_lessons').eq('user_id',user.id);
        if(alive&&data)setProgress(Object.fromEntries(data.map((r:{course_id:string;completed_lessons:string[]})=>[r.course_id,r.completed_lessons??[]])));
      }
      if(alive)setLoading(false);
    })();
    return()=>{alive=false;};
  },[]);
  const lessons=(c:Course)=>c.units.flatMap(u=>u.lessons);
  const percent=(c:Course)=>Math.round((progress[c.id]??[]).length/lessons(c).length*100);
  const completed=Object.values(progress).reduce((n,a)=>n+a.length,0);
  const total=courses.reduce((n,c)=>n+lessons(c).length,0);
  const overall=Math.round(completed/total*100);
  const recommended=courses.find(c=>percent(c)>0&&percent(c)<100)??courses.find(c=>percent(c)<100)??courses[0];
  return <main className="relative z-10 min-h-screen bg-[#061018] text-[#EAF5FA]">
    <header className="sticky top-0 z-30 border-b border-[#203846] bg-[#061018]/95 backdrop-blur">
      <div className="mx-auto flex max-w-[1500px] items-center justify-between gap-4 px-5 py-4">
        <Link href="/" className="flex items-center gap-3"><span className="flex h-10 w-10 items-center justify-center rounded-xl border border-[#087A76] bg-[#073438] text-xl text-[#00E5C3]">⬡</span><span className="leading-tight"><strong className="block text-sm tracking-[.2em]">NIGHTSHIFT</strong><span className="text-[10px] tracking-[.25em] text-[#00E5C3]">CYBER ACADEMY</span></span></Link>
        <div className="flex flex-wrap items-center justify-end gap-2 text-sm"><Link href="/learning" className="rounded-lg px-3 py-2 text-[#A9C0CD] hover:bg-[#0E2632] hover:text-[#00E5C3]">Learning paths</Link><Link href="/practice" className="rounded-lg px-3 py-2 text-[#A9C0CD] hover:bg-[#0E2632] hover:text-[#00E5C3]">Practice</Link><Link href="/arena" className="rounded-lg bg-[#00D7B8] px-4 py-2 font-bold text-[#032023]">Enter battle arena ↗</Link></div>
      </div>
    </header>
    <div className="mx-auto max-w-[1500px] px-5 py-8">
      <div className="relative overflow-hidden rounded-3xl border border-[#1B5361] bg-gradient-to-r from-[#0C2B38] via-[#0A1C2A] to-[#07121D] p-7 md:p-10">
        <div className="pointer-events-none absolute -right-8 -top-24 h-80 w-80 rounded-full border border-[#00E5C3]/20"/><div className="pointer-events-none absolute right-16 top-10 h-48 w-48 rounded-full border border-[#00E5C3]/10"/>
        <p className="text-xs uppercase tracking-[.3em] text-[#00E5C3]">Operator dashboard</p><h1 className="mt-3 text-3xl font-bold tracking-tight md:text-5xl">Welcome back, {name}.</h1><p className="mt-4 max-w-2xl text-[#A6BFCC]">Build practical cybersecurity skills through structured learning, focused practice, and real-time knowledge battles. Start with one path, master the units, then move to the next.</p>
        <div className="mt-7 grid grid-cols-2 gap-3 md:max-w-3xl md:grid-cols-4"><Metric label="Learning paths" value={String(courses.length)}/><Metric label="Lessons completed" value={`${completed}/${total}`}/><Metric label="Overall progress" value={`${overall}%`}/><Metric label="Learning streak" value="Build yours"/></div>
        <div className="mt-6 flex flex-wrap gap-3"><Link href="/learning" className="rounded-lg bg-[#00D7B8] px-5 py-3 text-sm font-bold text-[#032023]">Explore learning paths →</Link><Link href="/arena" className="rounded-lg border border-[#3D6C79] bg-[#081D28]/80 px-5 py-3 text-sm font-semibold text-[#C7F8F1]">Find a 1v1 battle</Link></div>
      </div>
      <div className="mt-9 flex flex-wrap items-end justify-between gap-4"><div><p className="text-xs uppercase tracking-[.25em] text-[#00E5C3]">Continue your training</p><h2 className="mt-2 text-2xl font-bold">Recommended learning path</h2></div><Link href="/learning" className="text-sm font-semibold text-[#5CF3DF] hover:text-white">View all 11 paths →</Link></div>
      <div className="mt-5 grid gap-4 md:grid-cols-2 xl:grid-cols-3">{[recommended,...courses.filter(c=>c.id!==recommended.id).slice(0,5)].map((course,i)=>{const p=percent(course);return <Link key={course.id} href={`/learning?course=${course.id}`} className={`group flex min-h-[245px] flex-col rounded-2xl border p-5 transition hover:-translate-y-0.5 hover:border-[#00E5C3]/70 ${i===0?'border-[#176B70] bg-gradient-to-br from-[#0D3038] to-[#091720]':'border-[#203846] bg-gradient-to-br from-[#0D1C27] to-[#09151E]'}`}>
        <div className="flex items-start justify-between"><span className="flex h-11 w-11 items-center justify-center rounded-xl border border-[#1B6968] bg-[#073438] text-xl text-[#00E5C3]">{icons[course.icon]??'⬡'}</span><span className="rounded-md border border-[#2A4351] px-2 py-1 text-[11px] text-[#9CB4C3]">{course.level}</span></div><p className="mt-5 text-[10px] uppercase tracking-[.25em] text-[#00E5C3]">{i===0?'Recommended next':course.category}</p><h3 className="mt-1 text-lg font-bold group-hover:text-[#6FF4E1]">{course.title}</h3><p className="mt-2 flex-1 text-sm leading-6 text-[#9CB4C3]">{course.description}</p><div className="mt-4 flex gap-4 text-xs text-[#8DA5B4]"><span>{course.units.length} units</span><span>{lessons(course).length} lessons</span></div><div className="mt-4 flex items-center gap-3"><div className="h-1.5 flex-1 overflow-hidden rounded-full bg-[#1B3341]"><div className="h-full rounded-full bg-gradient-to-r from-[#00E5C3] to-[#36A8FF]" style={{width:`${p}%`}}/></div><span className="w-9 text-right text-xs text-[#A8BBC7]">{p}%</span></div><div className="mt-4 flex items-center justify-between text-sm font-semibold text-[#5CF3DF]"><span>{p?'Continue learning':'Start learning'}</span><span>→</span></div>
      </Link>})}</div>
      <div className="mt-9 grid gap-4 md:grid-cols-3">
        <Link href="/practice" className="rounded-2xl border border-[#203846] bg-[#0B1923] p-5 hover:border-[#00E5C3]/60"><p className="text-xs uppercase tracking-[.2em] text-[#00E5C3]">Solo training</p><h3 className="mt-2 text-lg font-bold">Practice questions</h3><p className="mt-2 text-sm text-[#91A8B7]">Network troubleshooting, security fundamentals, A+ support scenarios, and mixed drills.</p></Link>
        <Link href="/arena" className="rounded-2xl border border-[#203846] bg-[#0B1923] p-5 hover:border-[#00E5C3]/60"><p className="text-xs uppercase tracking-[.2em] text-[#00E5C3]">Live competition</p><h3 className="mt-2 text-lg font-bold">1v1 Battle Arena</h3><p className="mt-2 text-sm text-[#91A8B7]">Choose a subject, challenge your knowledge, and compete using the existing real-time battle system.</p></Link>
        <Link href="/leaderboard" className="rounded-2xl border border-[#203846] bg-[#0B1923] p-5 hover:border-[#00E5C3]/60"><p className="text-xs uppercase tracking-[.2em] text-[#00E5C3]">Community</p><h3 className="mt-2 text-lg font-bold">Leaderboard</h3><p className="mt-2 text-sm text-[#91A8B7]">Track ranked performance and see how your battle rating compares.</p></Link>
      </div>
      <p className="mt-8 text-xs text-[#648091]">{loading?'Loading account progress…':'Progress is tied to your signed-in account.'} If course saves are not available yet, apply migration 014 from the project’s Supabase migrations.</p>
    </div>
  </main>;
}
function Metric({label,value}:{label:string;value:string}){return <div className="rounded-xl border border-[#27505D] bg-[#061A25]/70 p-4"><p className="text-2xl font-bold text-[#00E5C3]">{value}</p><p className="mt-1 text-xs text-[#9CB4C3]">{label}</p></div>}
