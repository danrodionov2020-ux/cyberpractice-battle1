require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { evaluate } = require('mathjs');
const { getSupabase } = require('./supabase');

const SUBJECT_DIRS = {
  'AP Chemistry': 'apchem',
  'AP Biology': 'apbio',
  'Networking & Protocols': 'networking',
  'Cybersecurity': 'cybersecurity',
  'CompTIA A+': 'aplus',
  'Nightshift Mixed': 'mixed',
};

// ─── DB query ─────────────────────────────────────────────────────────────────

async function pickQuestionsFromDB(subject, n) {
  const supabase = getSupabase();

  const { data: cards, error: cardsErr } = await supabase
    .from('source_cards')
    .select('id, unit')
    .eq('subject', subject)
    .eq('reviewed', true);

  if (cardsErr) throw cardsErr;
  if (!cards || cards.length === 0) throw new Error(`No reviewed cards for subject: ${subject}`);

  const unitMap = Object.fromEntries(cards.map(c => [c.id, c.unit]));

  // Shuffle card IDs in JS so every battle draws from a different random subset
  const cardIds = cards.map(c => c.id);
  for (let i = cardIds.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [cardIds[i], cardIds[j]] = [cardIds[j], cardIds[i]];
  }
  const sampleIds = cardIds.slice(0, n * 4);

  const { data: variants, error: varErr } = await supabase
    .from('question_variants')
    .select('id, rendered_stem, rendered_options, correct_index, source_card_id')
    .in('source_card_id', sampleIds)
    .not('rendered_options', 'is', null);

  if (varErr) throw varErr;
  if (!variants || variants.length === 0) throw new Error(`No variants for subject: ${subject}`);

  // Shuffle and return n
  for (let i = variants.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [variants[i], variants[j]] = [variants[j], variants[i]];
  }

  return variants.slice(0, n).map(row => ({
    id: row.id,
    stem: row.rendered_stem,
    options: row.rendered_options,
    correct_index: row.correct_index,
    source_card_id: row.source_card_id,
    unit: unitMap[row.source_card_id] ?? null,
  }));
}

// ─── JSON fallback helpers ────────────────────────────────────────────────────

function loadAllCards(subject) {
  const directory = SUBJECT_DIRS[subject];
  if (!directory) return [];
  const contentDir = path.join(__dirname, '..', 'content', directory);
  if (!fs.existsSync(contentDir)) return [];
  const files = fs.readdirSync(contentDir)
    .filter(f => /^unit\d+\.json$/.test(f))
    .sort();

  const cards = [];
  for (const file of files) {
    const raw = JSON.parse(fs.readFileSync(path.join(contentDir, file), 'utf8'));
    for (const card of raw) {
      if (card.type === 'mc_static' || card.type === 'mc_numeric') {
        cards.push(card);
      }
    }
  }
  return cards;
}

function evalFormula(formula, params) {
  return evaluate(formula, params);
}

function sampleParams(paramDefs) {
  const result = {};
  for (const [key, def] of Object.entries(paramDefs)) {
    const { min, max, step = 1 } = def;
    const steps = Math.floor((max - min) / step);
    result[key] = min + Math.floor(Math.random() * (steps + 1)) * step;
  }
  return result;
}

function fillTemplate(str, params) {
  return str.replace(/\{\{(\w+)\}\}/g, (_, k) => params[k] ?? `{{${k}}}`);
}

function renderCard(card) {
  if (card.type === 'mc_static') {
    // Shuffle static options on every draw while preserving the answer key.
    const options = [...card.content.options];
    const correctAnswer = options[card.content.correct_index];
    for (let i = options.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [options[i], options[j]] = [options[j], options[i]];
    }
    return {
      id: card.content.stem.slice(0, 32),
      source_card_id: card.id || `nightshift-${card.subject}-${card.deck}-${card.content.stem.slice(0, 16)}`,
      unit: card.unit || null,
      stem: card.content.stem,
      options,
      correct_index: options.indexOf(correctAnswer),
      explanation: card.content.correct_explanation || null,
    };
  }

  const { stem, params: paramDefs, answer_formula, precision = 2, unit = '', distractors } = card.content;

  for (let attempt = 0; attempt < 10; attempt++) {
    const params = sampleParams(paramDefs);
    const fmt = (v) => {
      const n = parseFloat(v.toFixed(precision));
      return unit ? `${n} ${unit}` : String(n);
    };

    let answerVal;
    try { answerVal = evalFormula(answer_formula, params); } catch { continue; }
    if (!isFinite(answerVal)) continue;

    const answerStr = fmt(answerVal);
    const distractorStrs = [];
    let ok = true;
    for (const d of distractors) {
      let dVal;
      try { dVal = evalFormula(d.formula, params); } catch { ok = false; break; }
      if (!isFinite(dVal)) { ok = false; break; }
      const dStr = fmt(dVal);
      if (dStr === answerStr || distractorStrs.includes(dStr)) { ok = false; break; }
      distractorStrs.push(dStr);
    }
    if (!ok) continue;

    const options = [answerStr, ...distractorStrs];
    for (let i = options.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [options[i], options[j]] = [options[j], options[i]];
    }

    return {
      id: `${answer_formula}_${JSON.stringify(params)}`,
      stem: fillTemplate(stem, params),
      options,
      correct_index: options.indexOf(answerStr),
    };
  }

  return null;
}

const cachedCards = new Map();
function pickQuestionsFromJSON(subject, n) {
  if (!cachedCards.has(subject)) cachedCards.set(subject, loadAllCards(subject));
  const subjectCards = cachedCards.get(subject) ?? [];
  const pool = [...subjectCards];
  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }
  const questions = [];
  for (const card of pool) {
    if (questions.length >= n) break;
    const q = renderCard(card);
    if (q) questions.push(q);
  }
  return questions;
}

// ─── Public API ───────────────────────────────────────────────────────────────

async function pickQuestions(subject, n = 10) {
  if (process.env.SUPABASE_URL) {
    try {
      return await pickQuestionsFromDB(subject, n);
    } catch (err) {
      console.warn('[questions] DB failed, falling back to JSON:', err.message);
    }
  }
  return pickQuestionsFromJSON(subject, n);
}

module.exports = { pickQuestions };
