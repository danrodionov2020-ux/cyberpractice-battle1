'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { getSocket } from '@/lib/socket';
import { createClient } from '@/lib/supabase/client';
import BattleRoom from '@/components/BattleRoom';
import NavBar from '@/components/NavBar';
import RankBadge from '@/components/RankBadge';
import AddFriendButton from '@/components/AddFriendButton';
import FriendsPanel, { type IncomingChallenge } from '@/components/FriendsPanel';
import AnswerButton, { deriveAnswerState } from '@/components/AnswerButton';
import { DEFAULT_SUBJECT, LIVE_SUBJECTS } from '@/lib/constants';
import { eloToTier, nextTierFor, tierProgressFor } from '@/lib/rank';

function AnimatedEloSection({ before, after }: { before: number | null; after: number | null }) {
  const [counter, setCounter] = useState<number | null>(before);
  const [showDelta, setShowDelta] = useState(false);

  useEffect(() => {
    if (before === null || after === null) return;
    const fromElo: number = before;
    const toElo: number = after;
    const DELAY = 700;
    const DURATION = 1600;
    let rafId: number;
    const t1 = setTimeout(() => {
      setShowDelta(true);
      const start = performance.now();
      function tick() {
        const elapsed = performance.now() - start;
        const t = Math.min(elapsed / DURATION, 1);
        const eased = 1 - Math.pow(1 - t, 3);
        setCounter(Math.round(fromElo + (toElo - fromElo) * eased));
        if (t < 1) rafId = requestAnimationFrame(tick);
      }
      rafId = requestAnimationFrame(tick);
    }, DELAY);
    return () => { clearTimeout(t1); cancelAnimationFrame(rafId); };
  }, [before, after]);

  if (before === null || counter === null) return null;
  const delta = after !== null ? after - before : null;

  return (
    <div className="flex flex-col items-center gap-1.5">
      {delta !== null && delta !== 0 && (
        <p className={`text-xs font-display font-bold tabular-nums transition-all duration-300 ${
          showDelta ? 'opacity-100' : 'opacity-0'
        } ${delta > 0 ? 'text-[#22C55E]' : 'text-[#EF4444]'}`}>
          {delta > 0 ? '+' : ''}{delta}
        </p>
      )}
      <p className="font-display font-black text-xl tabular-nums text-[#F5F0E8]">{counter}</p>
      <RankBadge elo={counter} size="sm" />
    </div>
  );
}

const MVP_SUBJECTS = LIVE_SUBJECTS;


type AppPhase =
  | 'idle'
  | 'queuing'
  | 'countdown'
  | 'battle'
  | 'finished'
  | 'complete';

interface Question {
  id: string;
  stem: string;
  options: string[];
  correct_index: number;
  source_card_id: string;
  unit: string | null;
}

interface BattleReviewItem {
  question: Question;
  selectedIndex: number;
  correct: boolean;
}

type ExplanationMap = Record<string, { correctExplanation: string | null; distractorExplanations: string[] }>;

const PLACEMENT_TOTAL = 5;

interface BattleState {
  phase: 'question' | 'reveal' | 'waiting';
  question: Question | null;
  qIndex: number;
  qTotal: number;
  selectedIndex: number | null;
  correctIndex: number | null;
  lastCorrect: boolean | null;
  opponentAnswer: number | null;
  opponentAnswered: boolean;
  myScore: number;
  oppScore: number;
  oppQIndex: number;
}

export default function Home() {
  const router = useRouter();
  const [appPhase, setAppPhase] = useState<AppPhase>('idle');
  const [userId, setUserId] = useState<string | null>(null);
  const [displayName, setDisplayName] = useState('');
  const [socketStatus, setSocketStatus] = useState<'connecting' | 'connected' | 'offline'>('connecting');
  const [queueError, setQueueError] = useState<string | null>(null);
  const [subject, setSubject] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      const s = localStorage.getItem('lastSubject');
      if (LIVE_SUBJECTS.includes(s as typeof LIVE_SUBJECTS[number])) return s;
    }
    return DEFAULT_SUBJECT;
  });
  const [roomId, setRoomId] = useState<string | null>(null);
  const [opponent, setOpponent] = useState<{ displayName: string; userId: string } | null>(null);
  const [countdown, setCountdown] = useState(3);
  const [winner, setWinner] = useState<string | null>(null);
  const [forfeit, setForfeit] = useState<{ forfeitedBy: string | null } | null>(null);
  const [finalScores, setFinalScores] = useState<Record<string, number>>({});
  const [finalTimes, setFinalTimes] = useState<Record<string, number | null>>({});
  const [myElo, setMyElo] = useState<number | null>(null);
  const [myEloBefore, setMyEloBefore] = useState<number | null>(null);
  const [opponentElo, setOpponentElo] = useState<number | null>(null);
  const [opponentEloAfter, setOpponentEloAfter] = useState<number | null>(null);
  const [isOpponentFriend, setIsOpponentFriend] = useState(false);
  const [showPracticeLeaveModal, setShowPracticeLeaveModal] = useState(false);
  const [iqpQuestions, setIqpQuestions] = useState<{ id: string; stem: string; options: string[]; correctIndex: number; correctExplanation: string | null }[]>([]);
  const [iqpIdx, setIqpIdx] = useState(0);
  const [iqpSelected, setIqpSelected] = useState<number | null>(null);
  const [iqpLoading, setIqpLoading] = useState(false);
  const [queueElapsed, setQueueElapsed] = useState(0);

  // Placements
  const [placementsPlayed, setPlacementsPlayed] = useState<number | null>(null);
  const [placementsAtBattleStart, setPlacementsAtBattleStart] = useState<number | null>(null);
  const placementsPlayedRef = useRef<number | null>(null);

  // Battle review + distractor explanations
  const [battleReviewItems, setBattleReviewItems] = useState<BattleReviewItem[]>([]);
  const [battleExplanations, setBattleExplanations] = useState<ExplanationMap>({});
  const [showBattleReview, setShowBattleReview] = useState(false);
  const currentBattleQuestionRef = useRef<Question | null>(null);
  useEffect(() => {
    placementsPlayedRef.current = placementsPlayed;
  }, [placementsPlayed]);

  const questionStartedAt = useRef<number | null>(null);
  const userIdRef = useRef<string | null>(null);

  const loadInQueueQuestions = useCallback(async () => {
    setIqpLoading(true);
    try {
      const supabase = createClient();
      const { data: cards } = await supabase
        .from('source_cards')
        .select('id, content')
        .eq('subject', subject)
        .eq('reviewed', true);
      if (!cards?.length) return;
      const shuffled = [...cards].sort(() => Math.random() - 0.5).slice(0, 20);
      const cardIds = shuffled.map((c: { id: string }) => c.id);
      const explanationMap = new Map<string, string | null>(
        shuffled.map((c: { id: string; content: { correct_explanation?: string | null } | null }) => [
          c.id,
          c.content?.correct_explanation ?? null,
        ])
      );
      const { data: variants } = await supabase
        .from('question_variants')
        .select('id, rendered_stem, rendered_options, correct_index, source_card_id')
        .in('source_card_id', cardIds)
        .not('rendered_options', 'is', null)
        .limit(5);
      setIqpQuestions(
        (variants ?? []).map(
          (v: { id: unknown; rendered_stem: unknown; rendered_options: unknown; correct_index: unknown; source_card_id: unknown }) => ({
            id: v.id as string,
            stem: v.rendered_stem as string,
            options: (v.rendered_options as string[]) ?? [],
            correctIndex: (v.correct_index as number) ?? 0,
            correctExplanation: explanationMap.get(v.source_card_id as string) ?? null,
          })
        )
      );
      setIqpIdx(0);
      setIqpSelected(null);
    } catch { /* non-fatal */ } finally {
      setIqpLoading(false);
    }
  }, [subject]);

  // ── Friends state ──────────────────────────────────────────────────────────
  const [friendsPanelOpen, setFriendsPanelOpen] = useState(false);
  const [friendsPendingCount, setFriendsPendingCount] = useState(0);
  const [friendsUnreadCount, setFriendsUnreadCount] = useState(0);
  const [onlineFriendIds, setOnlineFriendIds] = useState<Set<string>>(new Set());
  const [friendActivity, setFriendActivity] = useState<Record<string, { subject: string; phase: string } | null>>({});
  const [incomingChallenge, setIncomingChallenge] = useState<IncomingChallenge | null>(null);

  const [battle, setBattle] = useState<BattleState>({
    phase: 'question',
    question: null,
    qIndex: 0,
    qTotal: 0,
    selectedIndex: null,
    correctIndex: null,
    lastCorrect: null,
    opponentAnswer: null,
    opponentAnswered: false,
    myScore: 0,
    oppScore: 0,
    oppQIndex: 0,
  });

  useEffect(() => {
    const supabase = createClient();
    supabase.auth.getUser().then(async ({ data: { user } }) => {
      if (!user) { router.push('/login'); return; }
      setUserId(user.id);
      userIdRef.current = user.id;
      const { data } = await supabase
        .from('profiles')
        .select('display_name')
        .eq('id', user.id)
        .single();
      if (data) setDisplayName(data.display_name);
      // Register presence if socket is already connected
      const sock = getSocket();
      if (sock.connected) sock.emit('register_presence', { userId: user.id });
    });
  }, [router]);

  useEffect(() => {
    if (!userId) return;
    const supabase = createClient();
    supabase
      .from('elo_ratings')
      .select('rating')
      .eq('user_id', userId)
      .eq('subject', subject)
      .single()
      .then(({ data }) => setMyElo(data?.rating ?? 1000));
    supabase
      .from('battles')
      .select('id', { count: 'exact', head: true })
      .or(`player1_id.eq.${userId},player2_id.eq.${userId}`)
      .eq('subject', subject)
      .then(({ count }) => setPlacementsPlayed(count ?? 0));
  }, [userId, subject]);

  const resetBattleState = useCallback(() => {
    questionStartedAt.current = null;
    currentBattleQuestionRef.current = null;
    setBattleReviewItems([]);
    setBattleExplanations({});
    setShowBattleReview(false);
    setBattle({
      phase: 'question',
      question: null,
      qIndex: 0,
      qTotal: 0,
      selectedIndex: null,
      correctIndex: null,
      lastCorrect: null,
      opponentAnswer: null,
      opponentAnswered: false,
      myScore: 0,
      oppScore: 0,
      oppQIndex: 0,
    });
    setRoomId(null);
    setOpponent(null);
    setWinner(null);
    setForfeit(null);
    setFinalScores({});
    setMyEloBefore(null);
    setOpponentEloAfter(null);
    setIsOpponentFriend(false);
  }, []);

  useEffect(() => {
    if (appPhase === 'queuing') {
      const timer = window.setTimeout(() => { void loadInQueueQuestions(); }, 0);
      return () => window.clearTimeout(timer);
    } else {
      setIqpQuestions([]);
      setIqpIdx(0);
      setIqpSelected(null);
    }
  }, [appPhase, loadInQueueQuestions]);

  useEffect(() => {
    if (appPhase !== 'queuing') return;
    const id = setInterval(() => setQueueElapsed(s => s + 1), 1000);
    return () => clearInterval(id);
  }, [appPhase]);

  // When battle completes: fetch card content for the review panel + refresh placement count
  useEffect(() => {
    if (appPhase !== 'complete') return;
    if (!userId) return;
    const supabase = createClient();
    // Refresh placements count to show updated badge after this battle
    supabase
      .from('battles')
      .select('id', { count: 'exact', head: true })
      .or(`player1_id.eq.${userId},player2_id.eq.${userId}`)
      .eq('subject', subject)
      .then(({ count }) => setPlacementsPlayed(count ?? 0));
    // Fetch explanations for the review panel
    if (battleReviewItems.length === 0) return;
    const cardIds = [...new Set(battleReviewItems.map(r => r.question.source_card_id))];
    supabase
      .from('source_cards')
      .select('id, content')
      .in('id', cardIds)
      .then(({ data }) => {
        const map: ExplanationMap = {};
        for (const card of data ?? []) {
          const c = card.content as { correct_explanation?: string | null; distractor_explanations?: string[] | null } | null;
          map[card.id as string] = {
            correctExplanation: c?.correct_explanation ?? null,
            distractorExplanations: c?.distractor_explanations ?? [],
          };
        }
        setBattleExplanations(map);
      });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [appPhase]);

  useEffect(() => {
    const socket = getSocket();
    socket.connect();
    socket.on('connect', () => {
      setSocketStatus('connected');
      setQueueError(null);
      if (userIdRef.current) socket.emit('register_presence', { userId: userIdRef.current });
    });
    socket.on('connect_error', () => setSocketStatus('offline'));
    socket.on('disconnect', () => setSocketStatus('offline'));

    // ── Friends / presence events ──────────────────────────────────────────
    socket.on('presence_init', ({ onlineUserIds }: { onlineUserIds: string[] }) => {
      setOnlineFriendIds(new Set(onlineUserIds));
    });
    socket.on('friend_online', ({ userId: uid }: { userId: string }) => {
      setOnlineFriendIds(prev => new Set([...prev, uid]));
    });
    socket.on('friend_offline', ({ userId: uid }: { userId: string }) => {
      setOnlineFriendIds(prev => { const s = new Set(prev); s.delete(uid); return s; });
    });
    socket.on('friend_activity_update', ({ userId: uid, activity }: { userId: string; activity: { subject: string; phase: string } | null }) => {
      setFriendActivity(prev => {
        const next = { ...prev };
        if (activity === null) delete next[uid]; else next[uid] = activity;
        return next;
      });
    });
    socket.on('friend_challenge_received', ({ challengeId, fromUserId, fromDisplayName, subject }: { challengeId: string; fromUserId: string; fromDisplayName: string; subject: string }) => {
      setIncomingChallenge({ challengeId, fromUserId, fromDisplayName, subject, receivedAt: Date.now() });
    });
    socket.on('friend_challenge_declined', () => setIncomingChallenge(null));
    socket.on('friend_challenge_expired', () => setIncomingChallenge(null));
    socket.on('new_message', () => {
      // Only increment the NavBar badge when the panel is not open
      // (FriendsPanel manages per-friend counts internally when open)
      setFriendsPanelOpen(open => {
        if (!open) setFriendsUnreadCount(prev => prev + 1);
        return open;
      });
    });

    socket.on('queue_joined', () => { setQueueError(null); setQueueElapsed(0); setAppPhase('queuing'); });
    socket.on('queue_left', () => setAppPhase('idle'));
    socket.on('queue_timeout', () => { setQueueError('No opponent found yet. Try again when more players are online.'); setAppPhase('idle'); });
    socket.on('queue_error', ({ error }: { error: string }) => { setQueueError(error); setAppPhase('idle'); });

    socket.on('match_found', ({ roomId: rid, opponent: opp, myElo: serverMyElo }) => {
      setPlacementsAtBattleStart(placementsPlayedRef.current); // capture before-battle count
      setRoomId(rid);
      setOpponent({ displayName: opp.displayName, userId: opp.userId ?? '' });
      setOpponentElo(opp?.elo ?? 1000);
      if (typeof serverMyElo === 'number') setMyElo(serverMyElo);
      setAppPhase('countdown');
      // Check friendship with opponent
      if (userIdRef.current && opp?.userId) {
        const myUid = userIdRef.current;
        const oppUid = opp.userId;
        createClient()
          .from('friendships')
          .select('status')
          .or(`and(requester_id.eq.${myUid},addressee_id.eq.${oppUid}),and(requester_id.eq.${oppUid},addressee_id.eq.${myUid})`)
          .eq('status', 'accepted')
          .maybeSingle()
          .then(({ data }) => setIsOpponentFriend(!!data));
      }
      let n = 3;
      setCountdown(n);
      const t = setInterval(() => {
        n--;
        setCountdown(n);
        if (n <= 0) { clearInterval(t); setAppPhase('battle'); }
      }, 1000);
    });

    socket.on('question', ({ index, total, question }: { index: number; total: number; question: Question }) => {
      if (index === 0) questionStartedAt.current = Date.now();
      currentBattleQuestionRef.current = question;
      setAppPhase('battle');
      setBattle(prev => ({
        ...prev,
        phase: 'question',
        question,
        qIndex: index + 1,
        qTotal: total,
        selectedIndex: null,
        correctIndex: null,
        lastCorrect: null,
        opponentAnswer: null,
        opponentAnswered: false,
      }));
    });

    socket.on('question_result', ({ correct_index, your_answer, correct, score, opponent_score }: {
      correct_index: number;
      your_answer: number;
      correct: boolean;
      score: number;
      opponent_score: number;
    }) => {
      if (currentBattleQuestionRef.current) {
        const q = currentBattleQuestionRef.current;
        setBattleReviewItems(prev => [...prev, { question: q, selectedIndex: your_answer, correct }]);
      }
      setBattle(prev => ({
        ...prev,
        phase: 'reveal',
        correctIndex: correct_index,
        selectedIndex: your_answer ?? prev.selectedIndex,
        lastCorrect: correct,
        opponentAnswer: null,
        myScore: score,
        oppScore: opponent_score,
      }));
    });

    socket.on('opponent_progress', ({ score, questionIndex, answeredCurrent }: { score: number; questionIndex: number; answeredCurrent: boolean }) => {
      setBattle(prev => ({ ...prev, oppScore: score, oppQIndex: questionIndex, opponentAnswered: answeredCurrent }));
    });

    socket.on('waiting_for_opponent', ({ myScore, opponentScore }: { myScore: number; opponentScore: number }) => {
      setBattle(prev => ({ ...prev, phase: 'waiting', myScore, oppScore: opponentScore }));
    });

    socket.on('you_finished', ({ score, opponent_score }: { score: number; opponent_score: number }) => {
      setBattle(prev => ({ ...prev, myScore: score, oppScore: opponent_score }));
      setAppPhase('finished');
    });

    socket.on('battle_complete', ({ scores, winner: w, timeTakenMs, eloDeltas, forfeit: didForfeit, forfeitedBy }: { scores: Record<string, number>; winner: string | null; timeTakenMs: Record<string, number | null>; eloDeltas: Record<string, { before: number; after: number; delta: number }>; forfeit: boolean; forfeitedBy: string | null }) => {
      setFinalScores(scores);
      setFinalTimes(timeTakenMs ?? {});
      setWinner(w);
      setForfeit(didForfeit ? { forfeitedBy: forfeitedBy ?? null } : null);
      const myId = getSocket().id;
      if (myId && eloDeltas?.[myId]) {
        setMyEloBefore(eloDeltas[myId].before);
        setMyElo(eloDeltas[myId].after);
      }
      const oppSocketId = Object.keys(eloDeltas ?? {}).find(id => id !== myId);
      if (oppSocketId && eloDeltas?.[oppSocketId]) {
        setOpponentElo(eloDeltas[oppSocketId].before);
        setOpponentEloAfter(eloDeltas[oppSocketId].after);
      }
      setAppPhase('complete');
    });

    socket.on('opponent_disconnected', () => {
      // Informational only — server sends battle_complete immediately.
    });

    return () => { socket.disconnect(); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function joinQueue() {
    const socket = getSocket();
    if (socketStatus !== 'connected') {
      setQueueError('Battle server is reconnecting. Try again in a moment.');
      return;
    }
    setQueueError(null);
    socket.emit('join_queue', { userId: userId ?? socket.id, displayName, elo: myElo ?? 1000, subject });
  }

  function leaveQueue() {
    getSocket().emit('leave_queue');
  }

  function handlePracticeNavClick(e: React.MouseEvent<HTMLAnchorElement>) {
    if (appPhase === 'queuing') {
      e.preventDefault();
      setShowPracticeLeaveModal(true);
    }
  }

  function confirmLeaveForPractice() {
    leaveQueue();
    setShowPracticeLeaveModal(false);
    router.push('/practice');
  }

  async function handleSignOut() {
    await createClient().auth.signOut();
    router.push('/login');
  }

  function submitAnswer(index: number) {
    if (battle.selectedIndex !== null || battle.phase === 'reveal') return;
    setBattle(prev => ({ ...prev, selectedIndex: index }));
    const clientTimeTakenMs = questionStartedAt.current != null ? Date.now() - questionStartedAt.current : null;
    getSocket().emit('submit_answer', { roomId, answerIndex: index, clientTimeTakenMs });
  }

  function playAgain() {
    resetBattleState();
    setQueueElapsed(0);
    setAppPhase('queuing');
    const socket = getSocket();
    socket.emit('join_queue', { userId: userId ?? socket.id, displayName, elo: myElo ?? 1000, subject });
  }

  function returnToLobby() {
    resetBattleState();
    setAppPhase('idle');
  }

  function handleAcceptChallenge(challengeId: string) {
    getSocket().emit('accept_friend_challenge', { challengeId });
    setIncomingChallenge(null);
  }

  function handleDeclineChallenge(challengeId: string) {
    getSocket().emit('decline_friend_challenge', { challengeId });
    setIncomingChallenge(null);
  }

  // Placement badge — shown on RankBadge while still in placement matches
  const myPlacement =
    placementsPlayed !== null && placementsPlayed < PLACEMENT_TOTAL
      ? { current: placementsPlayed, total: PLACEMENT_TOTAL }
      : null;
  const lobbyElo = myElo ?? 1000;
  const lobbyTier = eloToTier(lobbyElo);
  const lobbyNextTier = nextTierFor(lobbyElo);

  // ── Complete ───────────────────────────────────────────────────────────────
  if (appPhase === 'complete') {
    const socket = getSocket();
    const myScore = finalScores[socket.id ?? ''] ?? battle.myScore;
    const oppScore = Object.entries(finalScores).find(([id]) => id !== socket.id)?.[1] ?? battle.oppScore;
    const myTimeMs = finalTimes[socket.id ?? ''] ?? null;
    const oppTimeMs = Object.entries(finalTimes).find(([id]) => id !== socket.id)?.[1] ?? null;
    const fmtTime = (ms: number | null) => ms != null ? `${(ms / 1000).toFixed(2)}s` : null;
    const iWon = winner === socket.id;
    const tied = winner === null;
    const wasForfeit = forfeit !== null;

    return (
      <main className="min-h-screen text-[#F5F0E8] flex flex-col items-center justify-center px-4 py-16">
        <div className="relative w-full max-w-md flex flex-col items-center">
          <div className="glow-focus animate-glow-pulse" />

          <div className="panel-raised panel-accent-top relative z-10 w-full px-8 py-10 flex flex-col items-center gap-7 animate-gold-burst">
            {/* Result heading */}
            <div className="flex flex-col items-center gap-2">
              <p className="text-[10px] text-[#F5F0E8]/30 uppercase tracking-[0.4em]">Match Result</p>
              <h2 className={`font-display font-black uppercase leading-none animate-vs-clash ${
                tied
                  ? 'text-6xl text-[#F5F0E8]/40 tracking-[0.15em]'
                  : iWon
                  ? 'text-7xl text-foil tracking-[0.12em]'
                  : 'text-7xl text-[#F5F0E8]/25 tracking-[0.15em]'
              }`}>
                {tied ? 'DRAW' : iWon ? 'VICTORY' : 'DEFEAT'}
              </h2>
            </div>

            {wasForfeit && (
              <p className={`text-[11px] uppercase tracking-[0.2em] font-medium text-center ${iWon ? 'text-[#22C55E]' : 'text-[#EF4444]/60'}`}>
                {iWon ? 'Opponent disconnected — you win' : 'You disconnected — counted as a loss'}
              </p>
            )}

            <div className="rule-gold w-full" />

            {/* Scores + animated ELO */}
            <div className="flex items-center justify-center gap-8 w-full">
              <div className="flex flex-col items-center gap-2 flex-1">
                <p className="text-[11px] text-[#F5F0E8]/40 uppercase tracking-[0.18em] truncate max-w-[8rem]">{displayName || 'You'}</p>
                <p className="font-display font-black text-6xl tabular-nums text-[#F5F0E8]">{myScore}</p>
                {fmtTime(myTimeMs) && (
                  <p className="text-[11px] text-[#00E5C3]/70 uppercase tracking-[0.2em] tabular-nums">{fmtTime(myTimeMs)}</p>
                )}
                {myEloBefore !== null
                  ? <AnimatedEloSection before={myEloBefore} after={myElo ?? myEloBefore} />
                  : <RankBadge elo={myElo} size="sm" />
                }
              </div>
              <span className="font-display font-black text-2xl uppercase tracking-[0.1em] text-[#2A2A2A] select-none">vs</span>
              <div className="flex flex-col items-center gap-2 flex-1">
                <p className="text-[11px] text-[#F5F0E8]/40 uppercase tracking-[0.18em] truncate max-w-[8rem]">{opponent?.displayName ?? 'Opponent'}</p>
                <p className="font-display font-black text-6xl tabular-nums text-[#F5F0E8]">{oppScore}</p>
                {fmtTime(oppTimeMs) && (
                  <p className="text-[11px] text-[#00E5C3]/70 uppercase tracking-[0.2em] tabular-nums">{fmtTime(oppTimeMs)}</p>
                )}
                {opponentEloAfter !== null
                  ? <AnimatedEloSection before={opponentElo ?? 1000} after={opponentEloAfter} />
                  : <RankBadge elo={opponentElo} size="sm" />
                }
              </div>
            </div>

            {/* Placement banner */}
            {(() => {
              const wasPlacement = placementsAtBattleStart !== null && placementsAtBattleStart < PLACEMENT_TOTAL;
              const isReveal = wasPlacement && placementsAtBattleStart === PLACEMENT_TOTAL - 1;
              const completedCount = wasPlacement ? placementsAtBattleStart + 1 : 0;
              if (!wasPlacement) return null;
              return (
                <div className={`w-full px-4 py-3 border text-center animate-rise-in ${
                  isReveal
                    ? 'border-[#00E5C3]/40 bg-[#00E5C3]/5'
                    : 'border-[#374151] bg-[#141414]'
                }`}>
                  {isReveal ? (
                    <>
                      <p className="text-[9px] text-[#00E5C3]/60 uppercase tracking-[0.3em] mb-1">Placements Complete</p>
                      <p className="text-sm font-display font-black uppercase tracking-[0.15em] text-[#00E5C3]">
                        Rank Revealed
                      </p>
                    </>
                  ) : (
                    <>
                      <p className="text-[9px] text-[#9CA3AF]/50 uppercase tracking-[0.3em] mb-1">Placement Match</p>
                      <p className="text-sm font-display font-bold uppercase tracking-[0.15em] text-[#9CA3AF]">
                        {completedCount} / {PLACEMENT_TOTAL} complete
                      </p>
                    </>
                  )}
                </div>
              );
            })()}

            {/* Add friend */}
            {opponent?.userId && userId && opponent.userId !== userId && !isOpponentFriend && (
              <div className="flex justify-center w-full">
                <AddFriendButton
                  viewerId={userId}
                  targetId={opponent.userId}
                  initialStatus="none"
                  friendshipId={null}
                />
              </div>
            )}

            {/* Actions */}
            <div className="flex gap-3 mt-1 w-full">
              <button
                onClick={playAgain}
                className="btn-gold flex-1 font-display font-black text-sm uppercase tracking-[0.18em] px-6 py-3"
              >
                Play Again
              </button>
              <button
                onClick={returnToLobby}
                className="btn-ghost flex-1 font-display font-bold text-sm uppercase tracking-[0.18em] px-6 py-3"
              >
                Lobby
              </button>
            </div>
          </div>
        </div>

        {/* Battle Review — collapsible per-question breakdown with explanations */}
        {battleReviewItems.length > 0 && (
          <div className="w-full max-w-md mt-4 panel overflow-hidden animate-rise-in">
            <button
              onClick={() => setShowBattleReview(v => !v)}
              className="w-full flex items-center justify-between px-5 py-4 text-left"
            >
              <p className="text-[9px] text-[#F5F0E8]/30 uppercase tracking-[0.3em]">Review</p>
              <span className="text-[#F5F0E8]/25 text-xs">{showBattleReview ? '▲' : '▼'}</span>
            </button>
            {showBattleReview && (
              <div className="border-t border-[#2A2A2A] divide-y divide-[#2A2A2A]">
                {battleReviewItems.map((item, idx) => {
                  const { question: q, selectedIndex, correct } = item;
                  const exp = battleExplanations[q.source_card_id];
                  const distractorRank = correct ? -1 : [0, 1, 2, 3].filter(i => i !== q.correct_index).indexOf(selectedIndex);
                  const distractorExp = distractorRank >= 0 ? (exp?.distractorExplanations[distractorRank] ?? null) : null;
                  return (
                    <div key={idx} className="px-5 py-4">
                      <p className="text-xs text-[#F5F0E8]/80 leading-snug mb-3">{q.stem}</p>
                      {!correct && (
                        <p className="text-[10px] text-[#EF4444]/80 mb-1">
                          ✗ {q.options[selectedIndex]}
                        </p>
                      )}
                      <p className="text-[10px] text-[#22C55E] mb-2">
                        ✓ {q.options[q.correct_index]}
                      </p>
                      {distractorExp && (
                        <div className="border-l-2 border-[#EF4444]/30 pl-3 mb-2">
                          <p className="text-[9px] text-[#EF4444]/50 uppercase tracking-[0.2em] mb-1">Why that&apos;s wrong</p>
                          <p className="text-[10px] text-[#F5F0E8]/50 leading-relaxed">{distractorExp}</p>
                        </div>
                      )}
                      {exp?.correctExplanation && (
                        <div className="border-l-2 border-[#00E5C3]/30 pl-3">
                          <p className="text-[9px] text-[#00E5C3]/50 uppercase tracking-[0.2em] mb-1">Explanation</p>
                          <p className="text-[10px] text-[#F5F0E8]/50 leading-relaxed">{exp.correctExplanation}</p>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </main>
    );
  }

  // ── Battle ─────────────────────────────────────────────────────────────────
  if (appPhase === 'battle' && battle.question) {
    const socket = getSocket();
    return (
      <BattleRoom
        battle={battle}
        opponent={opponent!}
        mySocketId={socket.id!}
        onSubmit={submitAnswer}
        myElo={myElo}
        opponentElo={opponentElo}
        displayName={displayName}
      />
    );
  }

  // ── Lobby / Queue / Countdown / Finished ───────────────────────────────────
  return (
    <>
      {(appPhase === 'idle' || appPhase === 'queuing') && (
        <NavBar
          displayName={displayName}
          elo={myElo}
          subject={appPhase === 'idle' ? subject : undefined}
          placement={myPlacement}
          onFriendsClick={() => { setFriendsPanelOpen(o => !o); setFriendsUnreadCount(0); }}
          friendsBadge={friendsPendingCount + friendsUnreadCount + (incomingChallenge ? 1 : 0)}
          onPracticeClick={handlePracticeNavClick}
        />
      )}

      {userId && (appPhase === 'idle' || appPhase === 'queuing') && (
        <FriendsPanel
          isOpen={friendsPanelOpen}
          onClose={() => setFriendsPanelOpen(false)}
          userId={userId}
          viewerSubject={subject}
          onlineUserIds={onlineFriendIds}
          friendActivity={friendActivity}
          incomingChallenge={incomingChallenge}
          onChallengeAccept={handleAcceptChallenge}
          onChallengeDecline={handleDeclineChallenge}
          onPendingCount={setFriendsPendingCount}
        />
      )}

      <main className="min-h-screen text-[#F5F0E8] flex flex-col items-center justify-center px-4 pt-12">
        {appPhase === 'idle' && (queueError || socketStatus !== 'connected') && (
          <div className={`w-full max-w-5xl mb-5 px-4 py-3 border text-xs flex items-center justify-between gap-4 ${
            queueError ? 'border-[#EF4444]/40 bg-[#EF4444]/5 text-[#F5F0E8]/75' : 'border-[#00E5C3]/30 bg-[#00E5C3]/5 text-[#F5F0E8]/55'
          }`} role="status" aria-live="polite">
            <span>{queueError ?? (socketStatus === 'connecting' ? 'Connecting to the battle server…' : 'Battle server unavailable.')}</span>
            {socketStatus !== 'connected' && (
              <button
                onClick={() => { setSocketStatus('connecting'); getSocket().connect(); }}
                className="flex-shrink-0 text-[#00E5C3] font-display font-bold uppercase tracking-[0.16em] hover:text-[#66F4DF]"
              >
                Retry
              </button>
            )}
          </div>
        )}

        {/* ── Idle ── */}
        {appPhase === 'idle' && (
          <div className="w-full max-w-5xl mx-auto animate-fade-up">
            <div className="flex flex-col lg:flex-row gap-6 items-start">

              {/* ── Left: Player card ── */}
              <div className="w-full lg:w-64 flex-shrink-0 flex flex-col gap-3">
                <div className="border border-[#2A2A2A] bg-[#141414] p-6 flex flex-col gap-5">
                  <div>
                    <p className="text-[10px] text-[#F5F0E8]/25 uppercase tracking-[0.3em] mb-2">Your ELO</p>
                    <p className="font-display font-black text-5xl tabular-nums leading-none" style={{ color: lobbyTier.color }}>{lobbyElo}</p>
                    <div className="mt-3 h-1 bg-[#2A2A2A]" role="progressbar" aria-label={`${lobbyTier.name} progress`} aria-valuemin={lobbyTier.min} aria-valuemax={lobbyNextTier?.min ?? lobbyElo} aria-valuenow={lobbyElo}>
                      <div className="h-full transition-all duration-500" style={{ width: `${tierProgressFor(lobbyElo) * 100}%`, backgroundColor: lobbyTier.color }} />
                    </div>
                    <p className="mt-2 text-[9px] text-[#F5F0E8]/30 uppercase tracking-[0.18em]">
                      {lobbyNextTier ? `${lobbyNextTier.min - lobbyElo} to ${lobbyNextTier.name}` : 'Highest tier'}
                    </p>
                  </div>
                  <div className="h-px bg-[#2A2A2A]" />
                  <div>
                    <p className="text-[10px] text-[#F5F0E8]/25 uppercase tracking-[0.3em] mb-1">Player</p>
                    <p className="text-sm text-[#F5F0E8]/70 font-medium truncate">{displayName || 'Loading profile…'}</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-[#F5F0E8]/25 uppercase tracking-[0.3em] mb-1">Subject</p>
                    <p className="text-sm text-[#00E5C3] font-semibold">{subject.replace('AP ', '')}</p>
                  </div>
                </div>
                <button
                  onClick={handleSignOut}
                  className="text-[#F5F0E8]/15 hover:text-[#F5F0E8]/40 text-[10px] uppercase tracking-[0.3em] transition-colors text-left px-1 py-1"
                >
                  Sign out
                </button>
              </div>

              {/* ── Right: Subject + CTA ── */}
              <div className="flex-1 flex flex-col gap-5">
                <div>
                  <p className="text-[10px] text-[#F5F0E8]/25 uppercase tracking-[0.3em] mb-4">Ranked Ladder</p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                    {MVP_SUBJECTS.map(s => {
                      const isLive = true;
                      const isSelected = subject === s;
                      return (
                        <button
                          key={s}
                          onClick={() => setSubject(s)}
                          disabled={!isLive}
                          className={`relative flex flex-col items-start px-5 py-4 border transition-all text-left ${
                            isSelected
                              ? 'border-[#00E5C3] bg-[#00E5C3]/10'
                              : isLive
                              ? 'border-[#2A2A2A] bg-[#141414] hover:border-[#00E5C3]/40 hover:bg-[#1C1C1C]'
                              : 'border-[#1C1C1C] bg-[#0D0D0D] opacity-40 cursor-not-allowed'
                          }`}
                        >
                          <div className="flex items-center justify-between w-full mb-2">
                            <span className={`text-[9px] uppercase tracking-[0.3em] font-bold ${
                              isSelected ? 'text-[#00E5C3]' : isLive ? 'text-[#22C55E]' : 'text-[#F5F0E8]/20'
                            }`}>
                              {isLive ? 'Live' : 'Soon'}
                            </span>
                            {isSelected && (
                              <span className="w-1.5 h-1.5 bg-[#00E5C3]" />
                            )}
                          </div>
                          <span className={`font-display font-bold text-sm uppercase tracking-wide leading-tight ${
                            isSelected ? 'text-[#00E5C3]' : isLive ? 'text-[#F5F0E8]/80' : 'text-[#F5F0E8]/25'
                          }`}>
                            {s.replace('AP ', '')}
                          </span>
                          <span className={`text-[10px] mt-0.5 ${isSelected ? 'text-[#00E5C3]/60' : 'text-[#F5F0E8]/20'}`}>
                            AP {s.includes('Calculus') ? 'Exam' : 'Exam'}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <button
                  onClick={joinQueue}
                  disabled={!displayName || socketStatus !== 'connected'}
                  className="w-full bg-[#00E5C3] hover:bg-[#66F4DF] disabled:opacity-30 disabled:cursor-not-allowed text-[#0A0A0A] font-display font-black text-xl uppercase tracking-[0.2em] py-5 transition-colors"
                >
                  Find Match
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ── Queuing ── */}
        {appPhase === 'queuing' && (
          <div className="relative flex flex-col items-center">
            <div className="glow-focus animate-glow-pulse" />
            <div className="panel-raised relative z-10 px-12 py-10 flex flex-col items-center gap-5 animate-rise-in">
              <p className="text-[10px] text-[#F5F0E8]/30 uppercase tracking-[0.4em]">Searching</p>
              <p className="font-display font-bold text-3xl uppercase tracking-[0.15em] text-[#F5F0E8]/60">
                Finding Opponent
              </p>
              <div className="rule-gold w-32" />
              <p className="text-[#00E5C3] text-xs uppercase tracking-[0.25em] font-bold">{subject}</p>
              <p className="text-[11px] text-[#F5F0E8]/35">
                {queueElapsed < 30 ? 'Matching by skill level' : 'Widening search…'}
              </p>
              <p className="text-[10px] text-[#F5F0E8]/20 tabular-nums -mt-3">{queueElapsed}s</p>
              <div className="flex gap-2 mt-1">
                <span className="w-2 h-2 bg-[#00E5C3] dot-1" />
                <span className="w-2 h-2 bg-[#00E5C3] dot-2" />
                <span className="w-2 h-2 bg-[#00E5C3] dot-3" />
              </div>
              <button
                onClick={leaveQueue}
                className="mt-2 text-[#F5F0E8]/20 hover:text-[#F5F0E8]/50 text-xs uppercase tracking-widest transition-colors"
              >
                Cancel
              </button>
            </div>
            {iqpQuestions.length > 0 && !iqpLoading && (() => {
              const iqpCurrent = iqpQuestions[iqpIdx % iqpQuestions.length];
              if (!iqpCurrent) return null;
              const isAnswered = iqpSelected !== null;
              return (
                <div className="mt-6 w-full max-w-sm animate-fade-up">
                  <p className="text-[9px] text-[#F5F0E8]/25 uppercase tracking-[0.3em] text-center mb-4">Practice while you wait</p>
                  <div
                    key={iqpIdx}
                    className="panel-raised panel-accent-top px-5 py-5 mb-4 animate-rise-in"
                  >
                    <p className="text-sm font-medium leading-relaxed text-[#F5F0E8]">{iqpCurrent.stem}</p>
                  </div>
                  <div className="flex flex-col gap-2">
                    {iqpCurrent.options.map((opt, i) => (
                      <AnswerButton
                        key={i}
                        index={i}
                        text={opt}
                        state={deriveAnswerState({
                          index: i,
                          selectedIndex: iqpSelected,
                          correctIndex: iqpCurrent.correctIndex,
                          isReveal: isAnswered,
                        })}
                        disabled={isAnswered}
                        onClick={setIqpSelected}
                        animationDelay={0.04 * i}
                      />
                    ))}
                  </div>
                  {isAnswered && iqpCurrent.correctExplanation && (
                    <div className="mt-4 panel px-4 py-3 border-l-2 border-[#00E5C3]/40 animate-fade-up">
                      <p className="text-[9px] text-[#00E5C3]/60 uppercase tracking-[0.25em] mb-1.5">Explanation</p>
                      <p className="text-xs text-[#F5F0E8]/70 leading-relaxed">{iqpCurrent.correctExplanation}</p>
                    </div>
                  )}
                  {isAnswered && (
                    <button
                      onClick={() => {
                        setIqpIdx(idx => idx + 1);
                        setIqpSelected(null);
                      }}
                      className="mt-3 w-full btn-gold text-xs font-display font-black uppercase tracking-[0.15em] py-2.5"
                    >
                      Next →
                    </button>
                  )}
                </div>
              );
            })()}
          </div>
        )}

        {/* ── Countdown ── */}
        {appPhase === 'countdown' && (
          <div className="relative flex flex-col items-center gap-10 w-full max-w-lg">
            <div className="glow-focus animate-glow-pulse" />

            {/* VS matchup */}
            <div className="relative z-10 flex items-center justify-center gap-6 w-full animate-rise-in">
              <div className="flex flex-col items-center gap-2 flex-1 text-right">
                <p className="font-display font-black text-xl uppercase tracking-[0.12em] text-[#F5F0E8] truncate max-w-full">
                  {displayName || 'You'}
                </p>
                <RankBadge elo={myElo} size="sm" placement={myPlacement} />
              </div>
              <span className="font-display font-black text-3xl uppercase text-[#00E5C3] animate-vs-clash select-none">
                VS
              </span>
              <div className="flex flex-col items-center gap-2 flex-1 text-left">
                <p className="font-display font-black text-xl uppercase tracking-[0.12em] text-[#F5F0E8] truncate max-w-full">
                  {opponent?.displayName}
                </p>
                <RankBadge elo={opponentElo} size="sm" />
              </div>
            </div>

            <div className="rule-gold relative z-10 w-2/3" />

            {isOpponentFriend && (
              <div className="relative z-10 flex items-center gap-1.5 px-3 py-1 border border-[#22C55E]/30 bg-[#22C55E]/5">
                <span className="w-1.5 h-1.5 bg-[#22C55E]" />
                <span className="text-[9px] text-[#22C55E]/70 uppercase tracking-[0.2em] font-display font-bold">Friends</span>
              </div>
            )}

            <p
              key={countdown}
              className="relative z-10 font-display font-black text-[10rem] leading-none text-foil tabular-nums animate-count-in select-none"
            >
              {countdown}
            </p>
          </div>
        )}

        {/* ── Finished (you answered all, waiting for opponent) ── */}
        {appPhase === 'finished' && (
          <div className="relative w-full max-w-md flex flex-col items-center">
            <div className="glow-focus animate-glow-pulse" />
            <div className="panel-raised panel-accent-top relative z-10 w-full px-8 py-9 flex flex-col items-center gap-6 animate-rise-in">
              <div className="flex flex-col items-center gap-1">
                <p className="font-display font-bold text-2xl uppercase tracking-[0.15em] text-[#F5F0E8]/55">
                  All Done
                </p>
                <p className="text-[#F5F0E8]/25 text-[11px] uppercase tracking-[0.2em]">Waiting for opponent to finish</p>
              </div>

              <div className="rule-gold w-full" />

              <div className="flex items-center justify-center gap-8 w-full">
                <div className="flex flex-col items-center gap-2 flex-1">
                  <p className="text-[11px] text-[#F5F0E8]/40 uppercase tracking-[0.18em] truncate max-w-[8rem]">{displayName || 'You'}</p>
                  <p className="font-display font-black text-6xl tabular-nums text-[#F5F0E8]">{battle.myScore}</p>
                  <RankBadge elo={myElo} size="sm" placement={myPlacement} />
                </div>
                <span className="font-display font-black text-2xl uppercase tracking-[0.1em] text-[#2A2A2A] select-none">vs</span>
                <div className="flex flex-col items-center gap-2 flex-1">
                  <p className="text-[11px] text-[#F5F0E8]/40 uppercase tracking-[0.18em] truncate max-w-[8rem]">{opponent?.displayName}</p>
                  <p className="font-display font-black text-6xl tabular-nums text-[#F5F0E8]">{battle.oppScore}</p>
                  <RankBadge elo={opponentElo} size="sm" />
                </div>
              </div>

              <div className="flex gap-2">
                <span className="w-2 h-2 bg-[#00E5C3] dot-1" />
                <span className="w-2 h-2 bg-[#00E5C3] dot-2" />
                <span className="w-2 h-2 bg-[#00E5C3] dot-3" />
              </div>
            </div>
          </div>
        )}
      </main>

      {showPracticeLeaveModal && (
        <div className="fixed inset-0 bg-black/60 z-[60] flex items-center justify-center px-4">
          <div className="panel-raised px-8 py-7 max-w-sm w-full flex flex-col gap-5 animate-rise-in">
            <p className="font-display font-black text-lg uppercase tracking-[0.15em] text-[#F5F0E8]">Leave Queue?</p>
            <p className="text-sm text-[#F5F0E8]/50 leading-relaxed">You&apos;ll lose your place in the matchmaking queue.</p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowPracticeLeaveModal(false)}
                className="flex-1 py-3 border border-[#2A2A2A] text-[#F5F0E8]/40 hover:text-[#F5F0E8]/70 text-xs font-display font-bold uppercase tracking-[0.15em] transition-colors"
              >
                Stay
              </button>
              <button
                onClick={confirmLeaveForPractice}
                className="flex-1 py-3 btn-gold text-xs font-display font-black uppercase tracking-[0.15em]"
              >
                Practice
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
