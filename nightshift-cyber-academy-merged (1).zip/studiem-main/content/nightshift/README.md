# Nightshift learning curriculum

`learning-paths.json` is the curriculum used by the `/learning` page. It contains 11 learning paths, 44 units, and 176 lesson steps. Each lesson includes a short teaching explanation, takeaways, and a checkpoint with an explanation. The content is authored for Nightshift and uses public standards as topic-level references; it is not copied from certification exams.

Topic references:
- NIST NICE Framework: https://www.nist.gov/itl/applied-cybersecurity/nice/nice-framework-resource-center/getting-started
- Cisco Networking Academy: https://www.cisco.com/site/us/en/learn/training-certifications/training/netacad/index.html
- Cisco networking basics: https://www-cloud-cdn.cisco.com/site/us/en/learn/topics/small-business/networking-basics.html
- OWASP Web Security Testing Guide: https://owasp.org/www-project-web-security-testing-guide/
- MITRE ATT&CK: https://attack.mitre.org/
- CompTIA A+ certification overview: https://www.comptia.org/certifications/a

Starter battle/practice questions are independently authored in sibling directories `networking`, `cybersecurity`, `aplus`, and `mixed`. The existing Studiem source bank contains AP Chemistry material; it did not contain a networking/cybersecurity/A+ question bank, so this integration adds a new original starter set instead of copying questions from third-party sites.
