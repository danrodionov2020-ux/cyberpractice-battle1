# Security Policy

## Reporting a vulnerability

Please **do not open a public GitHub issue** for security problems.

Report privately through GitHub's [Security Advisories](https://github.com/seanluofficial/studiem/security/advisories/new), or contact the repository owner directly.

Include where you can:

- What the issue is and roughly how severe you think it is
- Steps to reproduce, or a minimal proof of concept
- Affected files, endpoints, or socket events

You can expect an acknowledgement within a few days. Please give a reasonable window to ship a fix before disclosing publicly.

## Scope

In scope:

- The battle server (`server/`) — socket event handling, matchmaking, ELO writes, HTTP challenge endpoints
- The web app (`web/`) — auth flows, middleware guard, anything that leaks privileged data to the browser
- Supabase schema and RLS policies in `supabase/migrations/`

Out of scope:

- Vulnerabilities in third-party dependencies with no exploitable path in this codebase
- Findings that require an already-compromised machine or account
- Rate limiting or denial of service against non-production instances

## Security model

The server is the only authority; nothing arriving from a client is trusted.

- **All socket payloads are validated.** ELO is clamped to bounds with `NaN`/`Infinity` rejected, subjects are checked against a known set, display names are trimmed and length-capped, and client-reported timings are bounds-checked.
- **`roomId` is never used for authorization.** Membership is verified against server-side battle state.
- **The Supabase service role key lives only on the server.** The browser gets the anon key and has no write access to ELO or battle records.
- **Question selection happens server-side**, so clients cannot pre-load answers, and the `reviewed` gate cannot be bypassed.

Known open items are tracked in [`TECH_DEBT.md`](TECH_DEBT.md) and prioritized in [`DEVELOPMENT_ROADMAP.md`](DEVELOPMENT_ROADMAP.md).

## Please do not

- Test against the production deployment
- Access, modify, or exfiltrate other users' data
- Run automated scanners or load tests against live infrastructure
