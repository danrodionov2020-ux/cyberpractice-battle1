'use client';

import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { createClient } from '@/lib/supabase/client';
import curriculum from '@/data/learning-paths.json';

type Lesson = { id: string; title: string; duration: number; type: string; content: string; takeaways: string[]; check: { question: string; options: string[]; correct_index: number; explanation: string } };
type Unit = { id: string; title: string; lessons: Lesson[] };
type Course = { id: string; title: string; category: string; level: string; icon: string; description: string; duration: number; units: Unit[]; source: string };
const courses = curriculum as Course[];
const glyph: Record<string, string> = { shield:'⬡', network:'⌘', terminal:'>_', cpu:'▦', code:'</>', radar:'◉', cloud:'☁', key:'⌑', search:'⌕', target:'◎' };

export default function LearningPage() {
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [filter, setFilter] = useState('All paths');
  const [search, setSearch] = useState('');
  const [progress, setProgress] = useState<Record<string, string[]>>({});
  const [userId, setUserId] = useState<string | null>(null);
  const [activeLessonId, setActiveLessonId] = useState<string | null>(null);
  const [answer, setAnswer] = useState<number | null>(null);
  const [checked, setChecked] = useState(false);
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState('');

  useEffect(() => {
    const courseId = new URLSearchParams(window.location.search).get('course');
    const requested = courses.find(c => c.id === courseId);
    if (requested) {
      setSelectedCourse(requested);
      setActiveLessonId(requested.units[0]?.lessons[0]?.id ?? null);
    }
  }, []);

  useEffect(() => {
    let alive = true;
    const load = async () => {
      const supabase = createClient();
      const { data: { user } } = await supabase.auth.getUser();
      if (!alive) return;
      setUserId(user?.id ?? null);
      if (!user) return;
      const { data } = await supabase.from('learning_progress').select('course_id, completed_lessons').eq('user_id', user.id);
      if (alive && data) setProgress(Object.fromEntries(data.map((r: { course_id: string; completed_lessons: string[] }) => [r.course_id, r.completed_lessons ?? []])));
    };
    void load();
    return () => { alive = false; };
  }, []);

  const visibleCourses = useMemo(() => courses.filter(c =>
    (filter === 'All paths' || c.level === filter) &&
    `${c.title} ${c.category} ${c.description}`.toLowerCase().includes(search.toLowerCase())
  ), [filter, search]);

  const getLessons = (course: Course) => course.units.flatMap(u => u.lessons);
  const completedCount = (course: Course) => (progress[course.id] ?? []).length;
  const percent = (course: Course) => Math.round(completedCount(course) / getLessons(course).length * 100);
  const totalLessons = courses.reduce((sum, c) => sum + getLessons(c).length, 0);
  const completedTotal = courses.reduce((sum, c) => sum + completedCount(c), 0);
  const overall = Math.round(completedTotal / totalLessons * 100);
  const recommendedCourse = courses.find(c => percent(c) > 0 && percent(c) < 100) ?? courses.find(c => percent(c) < 100) ?? courses[0];
  const activeLesson = selectedCourse ? getLessons(selectedCourse).find(l => l.id === activeLessonId) ?? null : null;

  async function saveLesson(course: Course, lesson: Lesson) {
    if (!userId) { setNotice('Sign in to save learning progress to your account.'); return; }
    const updated = Array.from(new Set([...(progress[course.id] ?? []), lesson.id]));
    setProgress(prev => ({ ...prev, [course.id]: updated }));
    setSaving(true);
    const supabase = createClient();
    const { error } = await supabase.from('learning_progress').upsert({
      user_id: userId, course_id: course.id, completed_lessons: updated,
      last_lesson_id: lesson.id, updated_at: new Date().toISOString(),
    }, { onConflict: 'user_id,course_id' });
    setSaving(false);
    setNotice(error ? 'Progress shown for this session, but database save failed. Apply migration 014 and check Supabase permissions.' : 'Lesson complete — progress saved to your account.');
  }

  function openCourse(course: Course) {
    setSelectedCourse(course);
    const next = getLessons(course).find(l => !(progress[course.id] ?? []).includes(l.id)) ?? getLessons(course)[0];
    setActiveLessonId(next?.id ?? null);
    setAnswer(null); setChecked(false); setNotice('');
  }

  if (selectedCourse) {
    const course = selectedCourse;
    const lesson = activeLesson;
    const done = progress[course.id] ?? [];
    const lessons = getLessons(course);
    const currentIndex = lesson ? lessons.findIndex(l => l.id === lesson.id) : 0;
    const unitFor = (id: string) => course.units.find(u => u.lessons.some(l => l.id === id));
    const unit = lesson ? unitFor(lesson.id) : course.units[0];
    return <main className="relative z-10 min-h-screen bg-[#061018] text-[#EAF5FA]">
      <header className="sticky top-0 z-30 border-b border-[#203846] bg-[#061018]/95 backdrop-blur px-5 py-4 flex items-center justify-between">
        <Link href="/" className="font-black tracking-[.22em] text-sm text-[#00E5C3]">NIGHTSHIFT <span className="text-[#DCE8F0] font-normal">/ ACADEMY</span></Link>
        <button onClick={() => { setSelectedCourse(null); setActiveLessonId(null); setNotice(''); }} className="rounded-lg border border-[#284352] px-4 py-2 text-sm hover:border-[#00E5C3]">← All learning paths</button>
      </header>
      <div className="mx-auto max-w-7xl px-5 py-7">
        <div className="grid gap-6 lg:grid-cols-[250px_minmax(0,1fr)_260px]">
          <aside className="rounded-2xl border border-[#203846] bg-[#0B1923] p-4 h-fit">
            <p className="text-[10px] tracking-[.25em] text-[#00E5C3] uppercase">{course.category}</p>
            <h2 className="mt-2 text-xl font-bold">{course.title}</h2>
            <div className="mt-4 h-2 overflow-hidden rounded-full bg-[#1B3341]"><div className="h-full rounded-full bg-gradient-to-r from-[#00E5C3] to-[#36A8FF]" style={{width:`${percent(course)}%`}} /></div>
            <p className="mt-2 text-xs text-[#91A8B7]">{percent(course)}% complete · {done.length}/{lessons.length} lessons</p>
            <div className="mt-6 space-y-5">
              {course.units.map((u, ui) => <section key={u.id}>
                <p className="mb-2 text-xs font-semibold text-[#A9C0CD]">UNIT {ui+1} · {u.title}</p>
                <div className="space-y-1">{u.lessons.map((l, li) => <button key={l.id} onClick={() => {setActiveLessonId(l.id);setAnswer(null);setChecked(false);setNotice('');}} className={`w-full rounded-lg px-2.5 py-2 text-left text-xs flex items-center gap-2 ${activeLessonId===l.id?'bg-[#063C3D] text-[#63F4DF] border border-[#087A76]':'text-[#91A8B7] hover:bg-[#102632]'}`}>
                  <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full border border-[#315261]">{done.includes(l.id)?'✓':`${li+1}`}</span><span>{l.title}</span>
                </button>)}</div>
              </section>)}
            </div>
          </aside>
          <section className="min-w-0">
            <div className="rounded-2xl border border-[#203846] bg-gradient-to-br from-[#0D202D] to-[#08141D] p-6 md:p-8">
              <div className="flex flex-wrap items-center gap-2 text-xs text-[#86A6B8]"><span>Learning path</span><span>/</span><span>{unit?.title}</span><span>/</span><span>Lesson {currentIndex+1} of {lessons.length}</span></div>
              <div className="mt-6 flex flex-wrap items-start justify-between gap-4">
                <div><p className="text-[10px] uppercase tracking-[.25em] text-[#00E5C3]">{lesson?.type ?? 'LESSON'}</p><h1 className="mt-2 text-3xl font-bold tracking-tight">{lesson?.title ?? 'Choose a lesson'}</h1><p className="mt-3 text-sm text-[#9CB4C3]">{lesson?.duration ?? 10} min read · concept, application, knowledge check</p></div>
                <div className="rounded-xl border border-[#28505D] bg-[#0A2A31] px-4 py-3 text-center"><p className="text-2xl font-bold text-[#00E5C3]">{percent(course)}%</p><p className="text-[10px] uppercase tracking-widest text-[#91A8B7]">Course progress</p></div>
              </div>
              <div className="mt-7 space-y-4 text-[15px] leading-7 text-[#D1E0E8]">
                <p>{lesson?.content}</p>
                <div className="rounded-xl border border-[#24515B] bg-[#08252B] p-5"><h3 className="font-semibold text-[#63F4DF]">What you should be able to do</h3><ul className="mt-3 space-y-2">{lesson?.takeaways.map((t,i)=><li key={i} className="flex gap-2"><span className="text-[#00E5C3]">✓</span>{t}</li>)}</ul></div>
                <div className="rounded-xl border border-[#203846] bg-[#0A1720] p-5"><h3 className="font-semibold">Knowledge check</h3><p className="mt-2">{lesson?.check.question}</p><div className="mt-4 grid gap-2">{lesson?.check.options.map((o,i)=><button key={i} onClick={()=>{setAnswer(i);setChecked(false);}} className={`rounded-xl border px-4 py-3 text-left text-sm ${answer===i?'border-[#00E5C3] bg-[#07383A]':'border-[#284352] bg-[#0B1C26] hover:border-[#4A7180]'}`}>{String.fromCharCode(65+i)}. {o}</button>)}</div>
                  {checked && lesson && <div className={`mt-4 rounded-xl p-4 text-sm ${answer===lesson.check.correct_index?'bg-emerald-950/60 text-emerald-200':'bg-amber-950/50 text-amber-100'}`}><strong>{answer===lesson.check.correct_index?'Correct.':'Not quite.'}</strong> {lesson.check.explanation}</div>}
                  <div className="mt-4 flex flex-wrap gap-3"><button disabled={answer===null} onClick={()=>setChecked(true)} className="rounded-lg bg-[#00D7B8] px-4 py-2.5 text-sm font-bold text-[#032023] disabled:opacity-40">Check answer</button><button onClick={()=>lesson&&saveLesson(course,lesson)} disabled={!lesson||done.includes(lesson.id)||saving||!checked||answer!==lesson.check.correct_index} className="rounded-lg border border-[#2B5664] px-4 py-2.5 text-sm font-semibold text-[#6FF4E1] disabled:opacity-40">{done.includes(lesson?.id ?? '')?'Completed ✓':saving?'Saving…':(!checked||answer!==lesson?.check.correct_index)?'Pass checkpoint to complete':'Mark lesson complete'}</button></div>
                </div>
                <div className="flex justify-between gap-3"><button disabled={currentIndex<=0} onClick={()=>{setActiveLessonId(lessons[currentIndex-1]?.id ?? null);setAnswer(null);setChecked(false);}} className="rounded-lg border border-[#284352] px-4 py-2 text-sm disabled:opacity-30">← Previous lesson</button><button disabled={currentIndex>=lessons.length-1} onClick={()=>{setActiveLessonId(lessons[currentIndex+1]?.id ?? null);setAnswer(null);setChecked(false);}} className="rounded-lg bg-[#073D40] px-4 py-2 text-sm font-semibold text-[#6FF4E1] disabled:opacity-30">Next lesson →</button></div>
              </div>
            </div>
            {notice && <p className="mt-4 rounded-xl border border-[#24515B] bg-[#0A222B] p-3 text-sm text-[#A8D8D9]">{notice}</p>}
            <p className="mt-4 text-xs leading-5 text-[#648091]">Curriculum alignment: NIST NICE, Cisco Networking Academy, OWASP, MITRE ATT&CK and public CompTIA exam objectives. Lessons are original learning material, not exam dumps.</p>
          </section>
          <aside className="space-y-4">
            <div className="rounded-2xl border border-[#203846] bg-[#0B1923] p-5"><p className="text-xs uppercase tracking-widest text-[#00E5C3]">Next up</p><h3 className="mt-2 font-semibold">{lessons.find(l=>!done.includes(l.id))?.title ?? 'Path completed'}</h3><p className="mt-2 text-sm text-[#91A8B7]">Work through each lesson, answer the checkpoint, and mark it complete to track your progress.</p><button onClick={()=>{const next=lessons.find(l=>!done.includes(l.id));if(next){setActiveLessonId(next.id);setAnswer(null);setChecked(false);}}} className="mt-4 w-full rounded-lg bg-[#00D7B8] px-3 py-2 text-sm font-bold text-[#032023]">Continue learning</button></div>
            <div className="rounded-2xl border border-[#203846] bg-[#0B1923] p-5"><p className="text-xs uppercase tracking-widest text-[#91A8B7]">Path stats</p><div className="mt-4 space-y-3 text-sm"><div className="flex justify-between"><span className="text-[#91A8B7]">Units</span><strong>{course.units.length}</strong></div><div className="flex justify-between"><span className="text-[#91A8B7]">Lessons</span><strong>{lessons.length}</strong></div><div className="flex justify-between"><span className="text-[#91A8B7]">Estimated time</span><strong>{Math.round(course.duration/60)}h {course.duration%60}m</strong></div><div className="flex justify-between"><span className="text-[#91A8B7]">Difficulty</span><strong>{course.level}</strong></div></div></div>
            {!userId && <div className="rounded-xl border border-amber-800/60 bg-amber-950/30 p-4 text-xs text-amber-100">You are not signed in. Sign in to save course progress across sessions and devices.</div>}
          </aside>
        </div>
      </div>
    </main>;
  }

  return <main className="relative z-10 min-h-screen bg-[#061018] text-[#EAF5FA]">
    <header className="sticky top-0 z-30 flex items-center justify-between border-b border-[#203846] bg-[#061018]/95 px-5 py-4 backdrop-blur">
      <Link href="/" className="font-black tracking-[.22em] text-sm text-[#00E5C3]">NIGHTSHIFT <span className="font-normal text-[#DCE8F0]">CYBER ACADEMY</span></Link>
      <div className="flex gap-4 text-sm"><Link href="/practice" className="text-[#A7BBC8] hover:text-[#00E5C3]">Practice</Link><Link href="/" className="text-[#A7BBC8] hover:text-[#00E5C3]">Battle Arena</Link></div>
    </header>
    <div className="mx-auto max-w-7xl px-5 py-9">
      <div className="relative overflow-hidden rounded-3xl border border-[#1B5361] bg-gradient-to-r from-[#0C2B38] via-[#0A1C2A] to-[#07121D] p-7 md:p-10">
        <div className="absolute -right-10 -top-20 h-80 w-80 rounded-full border border-[#00E5C3]/20"/><div className="absolute right-10 top-6 h-56 w-56 rounded-full border border-[#00E5C3]/10"/>
        <p className="text-xs uppercase tracking-[.3em] text-[#00E5C3]">Your training environment</p><h1 className="mt-3 max-w-3xl text-4xl font-bold tracking-tight md:text-5xl">Build skills that hold up under pressure.</h1><p className="mt-4 max-w-2xl text-[#A6BFCC]">Structured paths from IT foundations to advanced detection and secure engineering. Learn a concept, apply it, check your understanding, and keep your progress.</p>
        <div className="mt-7 grid grid-cols-2 gap-3 md:max-w-2xl md:grid-cols-4"><Stat label="Learning paths" value={String(courses.length)}/><Stat label="Units" value={String(courses.reduce((s,c)=>s+c.units.length,0))}/><Stat label="Lessons" value={String(totalLessons)}/><Stat label="Overall progress" value={`${overall}%`}/></div><div className="mt-6 flex flex-wrap items-center justify-between gap-4 rounded-xl border border-[#27636A] bg-[#071E28]/80 p-4"><div><p className="text-[10px] uppercase tracking-[.24em] text-[#00E5C3]">Recommended next path</p><p className="mt-1 font-semibold">{recommendedCourse.title}</p><p className="mt-1 text-xs text-[#9CB4C3]">{completedCount(recommendedCourse)}/{getLessons(recommendedCourse).length} lessons complete · {recommendedCourse.level}</p></div><button onClick={()=>openCourse(recommendedCourse)} className="rounded-lg bg-[#00D7B8] px-4 py-2.5 text-sm font-bold text-[#032023]">Continue this path →</button></div>
      </div>
      <div className="mt-8 flex flex-col gap-4 md:flex-row md:items-end md:justify-between"><div><p className="text-xs uppercase tracking-[.25em] text-[#00E5C3]">Learning paths</p><h2 className="mt-2 text-2xl font-bold">Choose your next skill</h2></div><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search paths, skills, topics…" className="w-full rounded-xl border border-[#284352] bg-[#0A1923] px-4 py-3 text-sm outline-none focus:border-[#00E5C3] md:max-w-sm"/></div>
      <div className="mt-5 flex flex-wrap gap-2">{['All paths','Beginner','Intermediate','Advanced'].map(f=><button key={f} onClick={()=>setFilter(f)} className={`rounded-full border px-4 py-2 text-sm ${filter===f?'border-[#00E5C3] bg-[#073C3B] text-[#70F7E1]':'border-[#284352] text-[#9CB4C3] hover:border-[#4C7180]'}`}>{f}</button>)}</div>
      <div className="mt-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{visibleCourses.map(course=>{const p=percent(course);return <button key={course.id} onClick={()=>openCourse(course)} className="group flex min-h-[260px] flex-col rounded-2xl border border-[#203846] bg-gradient-to-br from-[#0D1C27] to-[#09151E] p-5 text-left transition hover:-translate-y-0.5 hover:border-[#00E5C3]/70 hover:shadow-[0_10px_45px_rgba(0,229,195,.08)]">
        <div className="flex items-start justify-between"><div className="flex h-11 w-11 items-center justify-center rounded-xl border border-[#1B6968] bg-[#073438] text-xl text-[#00E5C3]">{glyph[course.icon]??'⬡'}</div><span className="rounded-md border border-[#2A4351] px-2 py-1 text-[11px] text-[#9CB4C3]">{course.level}</span></div>
        <p className="mt-5 text-[10px] uppercase tracking-[.25em] text-[#00E5C3]">{course.category}</p><h3 className="mt-1 text-lg font-bold group-hover:text-[#6FF4E1]">{course.title}</h3><p className="mt-2 flex-1 text-sm leading-6 text-[#9CB4C3]">{course.description}</p>
        <div className="mt-4 flex flex-wrap gap-x-4 gap-y-2 text-xs text-[#8DA5B4]"><span>▤ {course.units.length} units</span><span>☷ {getLessons(course).length} lessons</span><span>◷ {Math.round(course.duration/60)}h</span></div>
        <div className="mt-4 flex items-center gap-3"><div className="h-1.5 flex-1 overflow-hidden rounded-full bg-[#1B3341]"><div className="h-full rounded-full bg-gradient-to-r from-[#00E5C3] to-[#36A8FF]" style={{width:`${p}%`}}/></div><span className="w-9 text-right text-xs text-[#A8BBC7]">{p}%</span></div><div className="mt-4 flex items-center justify-between text-sm font-semibold text-[#5CF3DF]"><span>{p?'Continue learning':'Open learning path'}</span><span>→</span></div>
      </button>})}</div>
      <footer className="mt-10 border-t border-[#203846] py-5 text-xs leading-5 text-[#648091]">Progress is tied to your signed-in Supabase account. To enable durable saves, apply migration <code>014_nightshift_learning_progress.sql</code> to the project's Supabase database. Learning material is original and aligned at topic level to public standards and objectives.</footer>
    </div>
  </main>;
}

function Stat({ label, value }: { label: string; value: string }) {
  return <div className="rounded-xl border border-[#27505D] bg-[#061A25]/70 p-4"><p className="text-2xl font-bold text-[#00E5C3]">{value}</p><p className="mt-1 text-xs text-[#9CB4C3]">{label}</p></div>;
}
