## What changed

<!-- One or two sentences. What does this PR do? -->

## Why

<!-- Link an issue, a TECH_DEBT.md ID, or a DEVELOPMENT_ROADMAP.md item where one applies. -->

## How to verify

<!-- Steps a reviewer can follow. For UI changes, attach a screenshot or clip. -->

## Checklist

- [ ] `npm run typecheck --prefix web` passes
- [ ] `node --check` passes on every changed file in `server/`
- [ ] No `any` types and no `@ts-ignore`
- [ ] Any new socket event validates its payload server-side (ELO, subject, display name, timings)
- [ ] No secrets, keys, or `.env` files committed
- [ ] New SQL lands in `supabase/migrations/NNN_description.sql` and is noted below

## Migrations

<!-- List any new migration files. Migrations are NOT auto-applied — say whether they have been run in the Supabase dashboard. Otherwise write "None". -->

None
