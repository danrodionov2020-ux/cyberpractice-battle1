-- Nightshift learning progress. Each row is owned by one authenticated Supabase user.
create table if not exists public.learning_progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  course_id text not null,
  completed_lessons text[] not null default '{}',
  last_lesson_id text,
  updated_at timestamptz not null default now(),
  primary key (user_id, course_id)
);
alter table public.learning_progress enable row level security;
drop policy if exists "learners can read own progress" on public.learning_progress;
create policy "learners can read own progress"
  on public.learning_progress for select using (auth.uid() = user_id);
drop policy if exists "learners can insert own progress" on public.learning_progress;
create policy "learners can insert own progress"
  on public.learning_progress for insert with check (auth.uid() = user_id);
drop policy if exists "learners can update own progress" on public.learning_progress;
create policy "learners can update own progress"
  on public.learning_progress for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
